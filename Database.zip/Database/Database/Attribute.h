#ifndef ATTRIBUTE_H_
#define ATTRIBUTE_H_

#include "Type.h"
#include <string>

struct Attribute{

	Type t;
	std::string name;

};

#endif