#ifndef CONNECTOR_H_
#define CONNECTOR_H_

enum Connector{AND, OR, NONE};

#endif