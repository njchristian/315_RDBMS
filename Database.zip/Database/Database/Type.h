#ifndef TYPE_H_
#define TYPE_H_

enum Type{ VARCHAR, INTEGER};

#endif