#include "Database.h"


int main(){

	Database d;

	/*
	Test functionality for 
	Create table
	Update
	Insert
	Delete
	Show
	Exit

	AND

	Selection
	Projection
	Rename
	Set Union
	Set Difference
	Cross Product
	Join
	*/


	return 1;
}