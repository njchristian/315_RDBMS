#ifndef OPERATION_H_
#define OPERATION_H_

enum Operation{ EQUALS, GR, GREQ, LE, LEQ, NEQ };

#endif