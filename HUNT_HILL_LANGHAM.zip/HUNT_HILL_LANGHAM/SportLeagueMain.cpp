#include "SportsLeague.h"
#include <iostream>



int main()
{
	SportsLeague league;
	league.run();
}